# Add final information to the script.

cat >> $LAYOUT_CODE <<EOF

set +x
set +e

LogPrint "Disk layout created."

EOF