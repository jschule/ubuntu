#
# prepare stuff for NBU
#

COPY_AS_IS=( "${COPY_AS_IS[@]}" "${COPY_AS_IS_NBU[@]}" )
COPY_AS_IS_EXCLUDE=( "${COPY_AS_IS_EXCLUDE[@]}" "${COPY_AS_IS_EXCLUDE_NBU[@]}" )
PROGS=( "${PROGS[@]}" "${PROGS_NBU[@]}" col )
