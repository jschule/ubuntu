# console setup

# load keymap
test -s /etc/dumpkeys.out && loadkeys /etc/dumpkeys.out


